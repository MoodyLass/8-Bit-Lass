///--------


                 Name: 8-bit-lass

                 Website:   https://8-bit-lass.pages.dev

                 Images: image folder

                 html css java :  code.pdf      -------------------///












To use the site offline: open the "index.html" file located inside the website folder


developer email: Tech@JesseJesse.com