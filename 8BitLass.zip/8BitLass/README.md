# 8BITLASS
## index.html<br>style.css<br>script.js
<img width="1439" alt="Screenshot 2023-09-03 at 2 48 52 PM" src="https://github.com/MoodyLass/8BitLass/assets/119916323/3890d68b-cfd8-4e56-ba7b-4f77e873d8be">
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">

  <link rel="stylesheet" href="./style.css">

</head>
<body>

<div id="cube">
  <div class="face back">
    <h1 class='neon'>8-Bit-Lass<br><img src="https://i.ibb.co/fxHrtS1/Screenshot-2023-08-20-at-2-42-42-AM.png" height="500px" frameborder="0"></a></h1>


  </div>
  <div class="face right"></div>
  <div class="face left"></div>
  <div class="face top"></div>
  <div class="face bottom"></div>
</div>
<section>
  <div>
    <p id='arrow'>&raquo;</p>
 </div>
</section>
</svg>

  </center>
  <img src="https://i.ibb.co/m6nVRZN/BG1.png" alt="BG1" border="0"></a>
  <img src="https://i.ibb.co/m6nVRZN/BG1.png" alt="BG1" border="0"></a><br>
  <a href="https://ibb.co/9rF4WX2"><img src="https://i.ibb.co/qrtgpG9/IMG-2099.png" alt="IMG-2099" frameborder="0"></a></p>
  <img src="https://i.ibb.co/m6nVRZN/BG1.png" alt="BG1" border="0"></a>
  <img src="https://i.ibb.co/m6nVRZN/BG1.png" alt="BG1" border="0"></a>
  </div>
</section><p>
<section>

  <div>

  <footer>
<center><img src="https://i.ibb.co/SVkrLNP/lani-rainbow.gif" alt="lani-rainbow" hieght="300px" width="300px" frameborder="0"></a><br><br>
<a href="mailto:lanikrewson@gmail.com" align="right" style="color:rgb(249, 250, 251)"><b>@8 Bit Lass</b></a>&nbsp; &nbsp; &nbsp;<a href="https://github.com/MoodyLass/8BitLass/edit/main/README.md)https://github.com/MoodyLass/8BitLass/edit/main/README.md">Source code</a>
  </footer>
</section>
</html>
